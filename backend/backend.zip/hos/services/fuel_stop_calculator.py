import requests
from math import radians, cos, sin, asin, sqrt


class FuelStopCalculator:
    # Typical truck fuel capacity in miles (1000 km = 621 miles)
    FUEL_RANGE = 621
    
    # Buffer percentage to refuel before running out
    REFUEL_BUFFER = 0.8  # Refuel when 80% of range consumed
    
    # Maximum number of fuel stops to avoid excessive API calls
    MAX_STOPS = 5
    
    # Search radius for fuel stations (in meters)
    FUEL_SEARCH_RADIUS = 25000  # 25 km

    def calculate(self, total_miles):
        """Calculate fuel stops based on total trip distance"""
        if total_miles <= self.FUEL_RANGE:
            return []
        
        fuel_stops = []
        miles_traveled = 0
        stop_number = 1
        
        while miles_traveled + self.FUEL_RANGE < total_miles:
            miles_traveled += self.FUEL_RANGE * self.REFUEL_BUFFER
            fuel_stops.append({
                "stop_number": stop_number,
                "miles_at": miles_traveled
            })
            stop_number += 1
        
        return fuel_stops

    def haversine(self, lon1, lat1, lon2, lat2):
        """Calculate great circle distance between two points on earth (in miles)"""
        lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
        c = 2 * asin(sqrt(a))
        km = 6371 * c
        return km * 0.621371  # Convert km to miles

    def geocode_address(self, address):
        """Geocode an address using Nominatim"""
        url = "https://nominatim.openstreetmap.org/search"
        params = {"q": address, "format": "json", "limit": 1}
        response = requests.get(url, params=params, headers={"User-Agent": "DriverApp"}, timeout=10)
        data = response.json()
        if not data:
            raise ValueError(f"Cannot geocode address: {address}")
        return {
            "lat": float(data[0]["lat"]),
            "lng": float(data[0]["lon"]),
            "name": data[0].get("display_name", address)
        }
