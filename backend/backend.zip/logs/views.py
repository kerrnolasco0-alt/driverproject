from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import FileResponse, Http404
import os
from django.conf import settings
import urllib.parse

# Create your views here.


class PdfListView(APIView):
    """List all generated PDFs for a trip"""
    
    def get(self, request):
        pdf_dir = os.path.join(settings.BASE_DIR, 'pdfs')
        if not os.path.exists(pdf_dir):
            return Response({'pdfs': []})
        
        try:
            pdfs = [f for f in os.listdir(pdf_dir) if f.endswith('.pdf')]
            return Response({'pdfs': pdfs})
        except Exception as e:
            return Response({'error': str(e)}, status=500)

