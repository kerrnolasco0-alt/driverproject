import requests

class Route:
    def __init__(self, geometry, total_miles):
        self.geometry = geometry
        self.total_miles = total_miles

class RouteService:

    def geocode(self, address):
        url = "https://nominatim.openstreetmap.org/search"
        params = {"q": address, "format": "json", "limit": 1}
        response = requests.get(url, params=params, headers={"User-Agent":"DriverApp"}, timeout=10)
        data = response.json()
        if not data:
            raise Exception(f"Cannot geocode {address}")
        return {"lat": float(data[0]["lat"]), "lng": float(data[0]["lon"]), "name": data[0].get("display_name", address)}

    def calculate_route(self, current, pickup, dropoff):
        if isinstance(current, str):
            current = self.geocode(current)
        if isinstance(pickup, str):
            pickup = self.geocode(pickup)
        if isinstance(dropoff, str):
            dropoff = self.geocode(dropoff)

        # Use OSRM to get full road polyline
        url = f"http://router.project-osrm.org/route/v1/driving/{current['lng']},{current['lat']};{pickup['lng']},{pickup['lat']};{dropoff['lng']},{dropoff['lat']}?overview=full&geometries=geojson"
        try:
            resp = requests.get(url, timeout=10).json()
            
            if 'routes' not in resp or not resp['routes']:
                raise Exception("No route found from OSRM")
            
            route_data = resp['routes'][0]
            # OSRM returns [lng, lat] coordinates - convert to [lat, lng] for consistency
            osrm_geometry = route_data['geometry']['coordinates']  # list of [lng, lat]
            geometry = [[lat, lng] for lng, lat in osrm_geometry]  # convert to [lat, lng]
            
            # Distance is in meters, convert to miles
            distance_miles = route_data['distance'] / 1609.34
            
            print(f"[ROUTE] Route loaded: {len(geometry)} points, {distance_miles:.1f} miles")
            return Route(geometry=geometry, total_miles=distance_miles)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Route calculation failed: {str(e)}")
        except (KeyError, IndexError) as e:
            raise Exception(f"Invalid OSRM response format: {str(e)}")