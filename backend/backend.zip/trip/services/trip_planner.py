import requests
from routing.services.route_service import RouteService
from hos.services.fuel_stop_calculator import FuelStopCalculator


class TripPlanner:

    def __init__(self):
        self.route_service = RouteService()
        self.fuel_calculator = FuelStopCalculator()

    def decode_route_geometry(self, route):
        """Convert route geometry to [lat, lng] format for Leaflet"""
        if isinstance(route.geometry, str):
            return self.decode_polyline(route.geometry)
        elif isinstance(route.geometry, list):
            # Convert [lng, lat] → [lat, lng] for Leaflet
            return [[lat, lng] for lng, lat in route.geometry]
        else:
            raise ValueError("Unknown route geometry format")

    def decode_polyline(self, encoded):
        """Decode Google polyline format"""
        index = 0
        lat = 0
        lng = 0
        coordinates = []
        while index < len(encoded):
            shift = 0
            result = 0
            byte = 0
            while True:
                byte = ord(encoded[index]) - 63
                index += 1
                result |= (byte & 0x1f) << shift
                shift += 5
                if byte < 0x20:
                    break
            dlat = ~(result >> 1) if result & 1 else result >> 1
            lat += dlat
            shift = 0
            result = 0
            while True:
                byte = ord(encoded[index]) - 63
                index += 1
                result |= (byte & 0x1f) << shift
                shift += 5
                if byte < 0x20:
                    break
            dlng = ~(result >> 1) if result & 1 else (result >> 1)
            lng += dlng
            coordinates.append([lat * 1e-5, lng * 1e-5])
        return coordinates

    def generate_real_fuel_stops(self, route_coords, total_distance):
        """
        Find gas stations along the route at strategic intervals based on fuel range.
        FUEL_RANGE = 621 miles, so calculate stops every ~497 miles (80% buffer).
        Limited to MAX_STOPS to avoid excessive API calls.
        """
        from hos.services.fuel_stop_calculator import FuelStopCalculator
        
        fuel_calc = FuelStopCalculator()
        fuel_stops = []
        
        # Calculate how many stops are needed
        miles_needed_for_fuel_interval = fuel_calc.FUEL_RANGE * fuel_calc.REFUEL_BUFFER
        
        print(f"[FUEL STOPS] Total distance: {total_distance} miles")
        print(f"[FUEL STOPS] Fuel range: {fuel_calc.FUEL_RANGE} miles")
        print(f"[FUEL STOPS] Miles per stop: {miles_needed_for_fuel_interval:.1f} miles")
        
        if total_distance <= fuel_calc.FUEL_RANGE:
            print(f"[FUEL STOPS] Trip is short ({total_distance} miles < {fuel_calc.FUEL_RANGE} miles). No stops needed.")
            return []
        
        # Number of stops needed (capped at MAX_STOPS)
        num_stops = min(fuel_calc.MAX_STOPS, max(1, int(total_distance / miles_needed_for_fuel_interval)))
        print(f"[FUEL STOPS] Calculated stops needed: {num_stops} (max: {fuel_calc.MAX_STOPS})")
        
        # Calculate distances at which to place fuel stops
        stop_distances = []
        for i in range(1, num_stops):
            distance = (total_distance / num_stops) * i
            stop_distances.append(distance)
        
        print(f"[FUEL STOPS] Stop distances: {[f'{d:.0f}mi' for d in stop_distances]}")
        
        # Convert distances to route indices
        route_length = len(route_coords)
        distance_per_index = total_distance / route_length if route_length > 0 else 0
        
        for stop_idx, stop_distance in enumerate(stop_distances):
            idx = int(stop_distance / distance_per_index) if distance_per_index > 0 else 0
            idx = min(idx, route_length - 1)
            
            if idx >= 0 and idx < route_length:
                lat, lng = route_coords[idx]
                print(f"[FUEL STOPS] Stop {stop_idx + 1}: distance={stop_distance:.0f}mi, route_idx={idx}, coords=({lat:.4f}, {lng:.4f})")
                
                # Query for fuel stations near this point
                try:
                    query = f"""
                    [out:json][timeout:3];
                    (
                      node["amenity"="fuel"](around:{fuel_calc.FUEL_SEARCH_RADIUS},{lat},{lng});
                    );
                    out center;
                    """
                    
                    print(f"[FUEL STOPS] Querying Overpass API for coordinates ({lat:.4f}, {lng:.4f})")
                    response = requests.get(
                        "https://overpass-api.de/api/interpreter",
                        params={"data": query},
                        timeout=3
                    )
                    
                    print(f"[FUEL STOPS] Overpass response status: {response.status_code}")
                    
                    if response.status_code == 200:
                        data = response.json()
                        elements = data.get("elements", [])
                        print(f"[FUEL STOPS] Found {len(elements)} fuel stations")
                        
                        if elements:
                            # Sort by distance from route point
                            elements_with_dist = []
                            for elem in elements:
                                if "lat" in elem and "lon" in elem:
                                    elem_lat, elem_lng = elem["lat"], elem["lon"]
                                    dist = fuel_calc.haversine(lng, lat, elem_lng, elem_lat)
                                    elements_with_dist.append((dist, elem))
                            
                            # Sort by distance and take closest ones
                            elements_with_dist.sort(key=lambda x: x[0])
                            
                            # Add up to 2 closest stations per stop
                            stations_added = 0
                            for dist, elem in elements_with_dist[:2]:
                                station_name = elem.get("tags", {}).get("name", "Fuel Station")
                                fuel_stops.append({
                                    "station_name": station_name,
                                    "lat": elem["lat"],
                                    "lng": elem["lon"],
                                    "stop_distance": stop_distance
                                })
                                print(f"[FUEL STOPS]   Added: {station_name} ({elem['lat']:.4f}, {elem['lon']:.4f}) - {dist:.1f}km away")
                                stations_added += 1
                        else:
                            print(f"[FUEL STOPS] No fuel elements found at this location")
                    else:
                        print(f"[FUEL STOPS] ERROR: Overpass API returned status {response.status_code}")
                        
                except requests.exceptions.Timeout:
                    print(f"[FUEL STOPS] ERROR: Overpass API timeout at stop {stop_idx + 1}")
                except requests.exceptions.RequestException as e:
                    print(f"[FUEL STOPS] ERROR: Request failed - {str(e)}")
                except Exception as e:
                    print(f"[FUEL STOPS] ERROR: {str(e)}")
        
        # Remove duplicates
        unique_stops = {}
        for stop in fuel_stops:
            key = (stop['lat'], stop['lng'])
            if key not in unique_stops:
                unique_stops[key] = stop
        
        real_stops = list(unique_stops.values())
        print(f"[FUEL STOPS] Total unique real stops found: {len(real_stops)}")
        
        # FALLBACK: If no real stops found, create synthetic stops at calculated distances
        if len(real_stops) == 0:
            print(f"[FUEL STOPS] No real stops found! Creating synthetic fuel stops as fallback...")
            synthetic_stops = []
            for stop_idx, stop_distance in enumerate(stop_distances):
                idx = int(stop_distance / distance_per_index) if distance_per_index > 0 else 0
                idx = min(idx, route_length - 1)
                if idx >= 0 and idx < route_length:
                    lat, lng = route_coords[idx]
                    synthetic_stops.append({
                        "station_name": f"Fuel Stop #{stop_idx + 1}",
                        "lat": lat,
                        "lng": lng,
                        "stop_distance": stop_distance,
                        "is_synthetic": True
                    })
                    print(f"[FUEL STOPS] Created synthetic stop: Fuel Stop #{stop_idx + 1} at {stop_distance:.0f}mi")
            return synthetic_stops
        
        return real_stops

    def generate_trip(self, request_data):
        """Generate complete trip with route and fuel stops"""
        try:
            current = request_data.get("current_location")
            pickup = request_data.get("pickup_location")
            dropoff = request_data.get("dropoff_location")
            driver_name = request_data.get("driver_name", "Unknown Driver")
            vehicle_type = request_data.get("vehicle_type", "Truck")

            if isinstance(current, str):
                current = self.fuel_calculator.geocode_address(current)
            if isinstance(pickup, str):
                pickup = self.fuel_calculator.geocode_address(pickup)
            if isinstance(dropoff, str):
                dropoff = self.fuel_calculator.geocode_address(dropoff)

            # Validate coordinates
            if not current or not pickup or not dropoff:
                raise ValueError("Invalid location data provided")

            print(f"[TRIP] Generating trip from {current.get('name')} to {dropoff.get('name')}")
            
            route = self.route_service.calculate_route(current, pickup, dropoff)
            route_coords = self.decode_route_geometry(route)
            
            # total_miles already converted to miles in route_service
            total_distance = route.total_miles
            
            if not route_coords or len(route_coords) == 0:
                raise ValueError("Route generation failed - no coordinates returned")
            
            fuel_stops = self.generate_real_fuel_stops(route_coords, total_distance)

            # Calculate trip summary (HOS = Hours of Service data)
            avg_speed = 60  # Typical truck speed
            total_drive_hours = total_distance / avg_speed if avg_speed > 0 else 0
            total_days = max(1, int(total_drive_hours / 10) + 1)  # Assume 10-hour driving per day

            # Waypoints in [lat, lng] format for consistency
            waypoints = [
                {"coordinates": [current["lat"], current["lng"]], "name": current.get("name", "Current Location")},
                {"coordinates": [pickup["lat"], pickup["lng"]], "name": pickup.get("name", "Pickup Location")},
                {"coordinates": [dropoff["lat"], dropoff["lng"]], "name": dropoff.get("name", "Destination")}
            ]

            trip_response = {
                "route": {
                    "geometry": route_coords,  # [lat, lng] format
                    "waypoints": waypoints  # [lat, lng] format
                },
                "fuel_stops": fuel_stops,
                "metadata": {
                    "origin": current.get("name", "Origin"),
                    "pickup": pickup.get("name", "Pickup"),
                    "destination": dropoff.get("name", "Destination"),
                    "date": __import__('datetime').datetime.now().strftime('%Y-%m-%d'),
                    "driver_name": driver_name,
                    "vehicle_type": vehicle_type
                },
                "trip_summary": {
                    "total_miles": round(total_distance, 1),
                    "total_drive_hours": round(total_drive_hours, 1),
                    "total_days": total_days,
                    "num_fuel_stops": len(fuel_stops)
                }
            }
            
            print(f"[TRIP] Generation complete: {len(route_coords)} route points, {len(fuel_stops)} fuel stops, {total_distance:.1f} miles")
            return trip_response
            
        except Exception as e:
            print(f"[TRIP] ERROR: {str(e)}")
            raise
